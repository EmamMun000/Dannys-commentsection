<?php
namespace Commentics;

class CommonFooterController extends Controller
{
    public function index()
    {
        return $this->data;
    }
}
